#include <stdio.h> 
#include <stdlib.h> 
#include <pthread.h>
#include <semaphore.h>

sem_t stick[5];
sem_t mutex;

void philozof(int n)
{
    printf("%d thinking\n", n);

    sem_wait(&mutex);
    sem_wait(&stick[n]);
    sem_wait(&stick[(n%5)+1]);

    printf("%d eating\n", n);
    usleep(1000000);
    printf("%d finished\n", n);

    sem_post(&stick[(n%5)+1]);
    sem_post(&stick[n]);
    sem_post(&mutex);

}

int main()
{
    pthread_t id[5];

    sem_init(&mutex,0,3);

    for (int i = 0; i < 5; i++)
    {
        sem_init(&stick[i],0,1);
    }

    for (int i = 0; i < 5; i++)
    {
        pthread_create(&id[i],NULL,philozof,i);
    }

    for (int i = 0; i < 5; i++)
    {
        pthread_join(id[i],NULL);
    }
}